Rules for entities in prefix demoSvc
