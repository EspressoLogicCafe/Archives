# APPLICATIONS
This folder contains definitions for applications
