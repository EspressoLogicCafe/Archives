# APPLICATION SKINS
This folder contains definitions for application skins
