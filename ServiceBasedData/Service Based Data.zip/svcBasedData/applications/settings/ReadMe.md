# APPLICATION SETTINGS
This folder contains definitions for application settings
