# APPLICATION OPTIONS
This folder contains definitions for application options
