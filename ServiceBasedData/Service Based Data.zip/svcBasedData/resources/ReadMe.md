# RESOURCES
This folder contains definitions for resources
